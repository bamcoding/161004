package net.gondor.constants;

public interface Session {
	public final static String SESSION_INFO = "_USER_INFO_";
}
