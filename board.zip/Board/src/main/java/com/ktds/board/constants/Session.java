package com.ktds.board.constants;

public interface Session {
	
	public static final String USER_INFO = "_USER_INFO_";

}
