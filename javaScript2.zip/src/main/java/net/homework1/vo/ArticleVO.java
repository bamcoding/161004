package net.homework1.vo;

public class ArticleVO {
	public int articlId;
	public String subject;
	public String content;
	public String createDate;
	
	public int getArticlId() {
		return articlId;
	}
	public void setArticlId(int articlId) {
		this.articlId = articlId;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getCreateDate() {
		return createDate;
	}
	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}

}
