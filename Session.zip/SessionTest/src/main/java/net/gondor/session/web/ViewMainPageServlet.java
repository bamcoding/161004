
package net.gondor.session.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class ViewMainPageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public ViewMainPageServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//session을 가져온다.
		HttpSession session = request.getSession();
		
		//id와 pw를 가져온다
		String userId = (String) session.getAttribute("userId");
		String userPassword= (String) session.getAttribute("userPassword");
		//id를 보여준다
		//pw를 보여준다.
		PrintWriter out = response.getWriter();
		out.print("userId : "+ userId + "<br/>");
		out.print("userPassword : " +userPassword +"<br/>");
		
		out.flush();
		out.close();
	}

}
